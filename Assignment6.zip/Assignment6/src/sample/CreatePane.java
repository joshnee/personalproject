package sample;// Assignment #: Arizona State University CSE205 #6
//         Name: Joshua Kades
//    StudentID: 1217713653
//      Lecture: T,Th 10:30-11:45 AM
//  Description: sample.CreatePane generates a pane where a user can enter
//  a club information and create a list of available clubs.

import java.util.ArrayList;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.geometry.*;
import javafx.scene.paint.*;
import javafx.scene.layout.HBox;

import javafx.event.ActionEvent;	//**Need to import
import javafx.event.EventHandler;	//**Need to import

import javax.swing.*;

//import all other necessary javafx classes here
//----
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;

public class CreatePane extends HBox
{
    ArrayList<Club> clubList;

    //The relationship between sample.CreatePane and sample.SelectPane is Aggregation
    private SelectPane selectPane;

    //constructor
    public CreatePane(ArrayList<Club> list, SelectPane sePane)
    {
        this.clubList = list;
        this.selectPane = sePane;


        //initialize each instance variable (textfields, labels, textarea, button, etc.)
        //and set up the layout
        //----

        Label titleLabel, numMembersLabel, theUniversityLabel, errorLabel;
        TextField titleTextField, numMembersTextField, universityTextField;
        Button createClub;
        TextArea whiteTextArea;


         errorLabel = new Label("");
         titleLabel = new Label("Title ");
         numMembersLabel = new Label("Number of Members ");
         theUniversityLabel = new Label("University ");
         titleTextField = new TextField();
         numMembersTextField = new TextField();
         universityTextField = new TextField();
         createClub = new Button("Create a Club");
         whiteTextArea = new TextArea("No Club");



        //create a GridPane hold those labels & text fields.
        //you can choose to use .setPadding() or setHgap(), setVgap()
        //to control the spacing and gap, etc.
        //----

            GridPane gridpane = new GridPane();
            gridpane.setAlignment(Pos.CENTER);

            gridpane.setHgap(5);
            gridpane.setVgap(5);


            gridpane.setPadding(new Insets(10,10,10,10));

            gridpane.add(errorLabel,0,0);
            
            gridpane.add(titleLabel,0,1);
            gridpane.add(numMembersLabel,0,2);
            gridpane.add(theUniversityLabel,0,3);


            gridpane.add(titleTextField, 1 , 1);
            gridpane.add(numMembersTextField,1,2);
            gridpane.add(universityTextField,1,3);
            

            
            
                       //add gridpane to broderpane using vbox. set gridpane first.


        //You might need to create a sub pane to hold the button
        //----
        Pane subpane = new Pane();


        //Set up the layout for the left half of the sample.CreatePane.
        //----
        BorderPane bordPaneOne = new BorderPane();

        bordPaneOne.getChildren().add(gridpane);
        bordPaneOne.setCenter(subpane);

        VBox theVBox = new VBox();

        theVBox.getChildren().add(bordPaneOne);

        whiteTextArea.setEditable(false);


        HBox theHBox = new HBox();
        theHBox.getChildren().addAll(theVBox, whiteTextArea);
        this.getChildren().addAll(theHBox);


        //the right half of the sample.CreatePane is simply a TextArea object
        //Note: a ScrollPane will be added to it automatically when there are no
        //enough space


        //Add the left half and right half to the sample.CreatePane
        //Note: sample.CreatePane extends from HBox
        //----

        //register/link source object with event handler
        //----

    } //end of constructor

    //Create a ButtonHandler class
    //ButtonHandler listens to see if the button "Create" is pushed or not,
    //When the event occurs, it get a club's Title, its number of members, and its university
    //information from the relevant text fields, then create a new club and add it inside
    //the clubList. Meanwhile it will display the club's information inside the text area.
    //using the toString method of the sample.Club class.
    //It also does error checking in case any of the textfields are empty,
    //or a non-numeric value was entered for its number of members
    private class ButtonHandler implements EventHandler<ActionEvent>
    {
        //Override the abstact method handle()
        public void handle(ActionEvent event)
        {
            //declare any necessary local variables here
            //---

            //when a text field is empty and the button is pushed
            //if ( //----  )
            //{
            //handle the case here

            //}
            //else	//for all other cases
            //{
            //when a non-numeric value was entered for its number of members
            //and the button is pushed
            //you will need to use try & catch block to catch
            //the NumberFormatException
            //----

            //When a club of an existing club name in the list
            //was attempted to be added, do not add it to the list
            //and display a message "sample.Club not added - duplicate"



            //at the end, don't forget to update the new arrayList
            //information on the SelectPanel
            //----

            //}

        } //end of handle() method
    } //end of ButtonHandler class

}